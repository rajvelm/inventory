export class Fees {
   public micCode:string;
   public exchangeName:string;
   public description:string;
   public dateTimeliness:string;
   public pearFeeType:string;
   public usageType:string;
   public currency:string;
   public fee:string;
   public frequency:string;
   public period:string;
   
} 