import { Component, OnInit, ViewChild} from '@angular/core';
//import { Component, ViewChild } from "@angular/core";
//import { Http } from "@angular/http";
//import { CustomLoadingOverlay } from "./custom-loading-overlay.component";
//import { CustomNoRowsOverlay } from "./custom-no-rows-overlay.component";


@Component({
  selector: 'app-feesupload',
  templateUrl: './feesupload.component.html',
  styleUrls: ['./feesupload.component.scss']
})

export class FeesuploadComponent
{

  constructor() 
  {
	  
  }
}
